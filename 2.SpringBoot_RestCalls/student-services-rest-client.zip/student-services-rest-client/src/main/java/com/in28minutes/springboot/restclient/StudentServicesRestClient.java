package com.in28minutes.springboot.restclient;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

public class StudentServicesRestClient implements IStudentServicesRestClient{

    @SuppressWarnings("rawtypes")
    public void retrieveCoursesForStudent(){
    	 RestTemplate restTemplate = new RestTemplate();
         List course_list = restTemplate.getForObject("http://localhost:8080/students/Satish/courses", List.class);
		List<LinkedHashMap> course_List1 = course_list;
         for(LinkedHashMap courseMap : course_List1) {
         	for(Object courseinfo: courseMap.keySet()) {
         		System.out.println(courseinfo+ "="+courseMap.get(courseinfo));
         	}
         	System.out.println("==============");
         }
    }

}