package com.in28minutes.springboot.restclient;

public interface IStudentServicesRestClient {
	public void retrieveCoursesForStudent();
}
