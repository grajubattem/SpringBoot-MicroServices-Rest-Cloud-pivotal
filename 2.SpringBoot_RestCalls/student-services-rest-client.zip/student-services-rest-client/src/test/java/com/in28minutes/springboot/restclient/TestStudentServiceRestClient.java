package com.in28minutes.springboot.restclient;


//unit test
//jnuit test case
//calling  rest  client
public class TestStudentServiceRestClient {
	public static void main(String[] args) {
		IStudentServicesRestClient restclient = new StudentServicesRestClient();
		restclient.retrieveCoursesForStudent();
	}
}
