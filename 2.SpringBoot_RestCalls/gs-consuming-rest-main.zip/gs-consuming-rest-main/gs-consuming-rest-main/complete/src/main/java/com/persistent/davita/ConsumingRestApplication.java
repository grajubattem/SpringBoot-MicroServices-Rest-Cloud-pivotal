package com.persistent.davita;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.List;

@SpringBootApplication
public class ConsumingRestApplication {

	private static final Logger log = LoggerFactory.getLogger(ConsumingRestApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(ConsumingRestApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
		return args -> {
			List<LinkedHashMap> employeeList = restTemplate.getForObject(
					"https://jsonplaceholder.typicode.com/users", List.class);
			log.info("result###"+employeeList.toString());
			for(int i=0; i<employeeList.size(); i++) {
				LinkedHashMap linkedHashMap = employeeList.get(i);
				Integer value = (Integer) linkedHashMap.get("id");
				if (value > 5) {
					System.out.println("Emp ID::::" + linkedHashMap.get("name"));
				}
			}
		};
	}
}
